#include <inttypes.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include "cJSON.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "esp_check.h"
#include "esp_attr.h"
#include "esp_partition.h"
#include "esp_image_format.h"
#include "esp_ota_ops.h"

#include "driver/gpio.h"
#include "esp_app_desc.h"
#include "esp_timer.h"
#include "esp_heap_caps.h"

#include "global_state.h"
#include "system.h"
#include "connect.h"
#include "nvs_config.h"
#include "display.h"
#include "input.h"
#include "screen.h"
#include "vcore.h"
#include "thermal.h"
#include "utils.h"
#include "self_test.h"
#include "filesystem.h"
#include "embedded_web_ui.h"
#include "work_queue.h"
#include "hashrate_monitor_task.h"

#define NVS_COUNTER_UPDATE_INTERVAL_MS 60 * 60 * 1000  // Update NVS once per hour
#define NOINIT_SENTINEL_VALUE 0x4C4F4732       // "LOG2" in hex

typedef struct
{
    uint64_t total_uptime;            // Total uptime in seconds
    uint64_t cumulative_hashes_high;  // High 64 bits of 128-bit cumulative hash count
    uint64_t cumulative_hashes_low;   // Low 64 bits of 128-bit cumulative hash count
    uint32_t sentinel;                // Magic value to detect valid noinit data
} NoinitState;    

__NOINIT_ATTR static NoinitState noinit_state; // Noinit state survives soft reboots but is lost on power cycle
static uint64_t last_update_time_ms;
static uint64_t last_nvs_write_time_ms;
static uint64_t total_uptime_at_system_start;

static const char * TAG = "system";

//local function prototypes
static esp_err_t ensure_overheat_mode_config();

static void parse_pool_config_json(const char *json_str, PoolConfig *cfg, int index) {
    // Set default values first
    cfg->protocol = STRATUM_PROTOCOL_V1;
    cfg->url = strdup(index == 0 ? CONFIG_STRATUM_URL : "");
    cfg->port = index == 0 ? CONFIG_STRATUM_PORT : 3333;
    cfg->user = strdup(index == 0 ? CONFIG_STRATUM_USER : "");
    cfg->pass = strdup(index == 0 ? CONFIG_STRATUM_PW : "x");
    cfg->difficulty = index == 0 ? CONFIG_STRATUM_DIFFICULTY : 0;
#ifdef CONFIG_STRATUM_EXTRANONCE_SUBSCRIBE
    cfg->extranonce_subscribe = true;
#else
    cfg->extranonce_subscribe = false;
#endif
    cfg->tls = index == 0 ? CONFIG_STRATUM_TLS : 0;
    cfg->cert = strdup("");
    cfg->decode_coinbase_tx = true;
    cfg->sv2_channel_type = SV2_CHANNEL_EXTENDED;
    cfg->sv2_authority_pubkey = strdup("");
    cfg->sv2_require_auth = false;

    if (!json_str || strlen(json_str) == 0) {
        return;
    }

    cJSON *root = cJSON_Parse(json_str);
    if (!root) {
        return;
    }

    cJSON *item;

    item = cJSON_GetObjectItem(root, "stratumProtocol");
    if (item && cJSON_IsString(item)) {
        stratum_protocol_t p = stratum_protocol_from_string(item->valuestring);
        if (p != STRATUM_PROTOCOL_UNKNOWN) cfg->protocol = p;
    }

    item = cJSON_GetObjectItem(root, "stratumURL");
    if (item && cJSON_IsString(item)) {
        free(cfg->url);
        cfg->url = strdup(item->valuestring);
    }

    item = cJSON_GetObjectItem(root, "stratumPort");
    if (item && cJSON_IsNumber(item)) {
        cfg->port = item->valueint;
    }

    item = cJSON_GetObjectItem(root, "stratumUser");
    if (item && cJSON_IsString(item)) {
        free(cfg->user);
        cfg->user = strdup(item->valuestring);
    }

    item = cJSON_GetObjectItem(root, "stratumPassword");
    if (item && cJSON_IsString(item)) {
        free(cfg->pass);
        cfg->pass = strdup(item->valuestring);
    }

    item = cJSON_GetObjectItem(root, "stratumSuggestedDifficulty");
    if (item && cJSON_IsNumber(item)) {
        cfg->difficulty = item->valueint;
    }

    item = cJSON_GetObjectItem(root, "stratumExtranonceSubscribe");
    if (item && (cJSON_IsBool(item) || cJSON_IsNumber(item))) {
        cfg->extranonce_subscribe = cJSON_IsTrue(item) || (cJSON_IsNumber(item) && item->valueint != 0);
    }

    item = cJSON_GetObjectItem(root, "stratumTLS");
    if (item && cJSON_IsNumber(item)) {
        cfg->tls = item->valueint;
    }

    item = cJSON_GetObjectItem(root, "stratumCert");
    if (item && cJSON_IsString(item)) {
        free(cfg->cert);
        cfg->cert = strdup(item->valuestring);
    }

    item = cJSON_GetObjectItem(root, "stratumDecodeCoinbase");
    if (item && (cJSON_IsBool(item) || cJSON_IsNumber(item))) {
        cfg->decode_coinbase_tx = cJSON_IsTrue(item) || (cJSON_IsNumber(item) && item->valueint != 0);
    }

    item = cJSON_GetObjectItem(root, "stratumV2ChannelType");
    if (item && cJSON_IsString(item)) {
        sv2_channel_type_t t = sv2_channel_type_from_string(item->valuestring);
        if (t != SV2_CHANNEL_UNKNOWN) cfg->sv2_channel_type = t;
    }

    item = cJSON_GetObjectItem(root, "stratumV2AuthorityPubkey");
    if (item && cJSON_IsString(item)) {
        free(cfg->sv2_authority_pubkey);
        cfg->sv2_authority_pubkey = strdup(item->valuestring);
    }

    item = cJSON_GetObjectItem(root, "stratumV2RequireAuth");
    if (item && (cJSON_IsBool(item) || cJSON_IsNumber(item))) {
        cfg->sv2_require_auth = cJSON_IsTrue(item) || (cJSON_IsNumber(item) && item->valueint != 0);
    }

    cJSON_Delete(root);
}

void SYSTEM_check_firmware_migration(void)
{
    const esp_app_desc_t *app_desc = esp_app_get_description();
    char current_fp[80];
    snprintf(current_fp, sizeof(current_fp), "%s_%s_%s", app_desc->version, app_desc->date, app_desc->time);

    char *last_fw_fp = nvs_config_get_string(NVS_CONFIG_LAST_FW_FINGERPRINT);
    if (!last_fw_fp || strcmp(last_fw_fp, current_fp) != 0) {
        if (nvs_config_get_bool(NVS_CONFIG_USE_CUSTOM_WWW)) {
            ESP_LOGI(TAG, "Firmware build changed (%s -> %s). Resetting custom WWW to default (false).⁠​‌‌​​​‌​​‌‌​‌​​‌​‌‌‌​‌​​​‌‌​​​​‌​‌‌‌‌​​​​‌‌​​‌​‌⁠",
                     (last_fw_fp && strlen(last_fw_fp) > 0) ? last_fw_fp : "none", current_fp);
            nvs_config_set_bool(NVS_CONFIG_USE_CUSTOM_WWW, false);
        }
        nvs_config_set_string(NVS_CONFIG_LAST_FW_FINGERPRINT, current_fp);
    }
    free(last_fw_fp);
}

void SYSTEM_reset_custom_www(void)
{
    nvs_config_set_bool(NVS_CONFIG_USE_CUSTOM_WWW, false);
    nvs_config_set_string(NVS_CONFIG_LAST_FW_FINGERPRINT, "");
}

void SYSTEM_init_system(GlobalState * GLOBAL_STATE)
{
    SystemModule * module = &GLOBAL_STATE->SYSTEM_MODULE;

    module->screen_page = 0;
    module->shares_accepted = 0;
    module->shares_rejected = 0;
    module->best_nonce_diff = nvs_config_get_u64(NVS_CONFIG_BEST_DIFF);
    module->best_session_nonce_diff = 0;
    module->start_time_us = esp_timer_get_time();
    module->lastClockSync = 0;
    module->block_found = 0;
    module->show_new_block = false;

    if (noinit_state.sentinel != NOINIT_SENTINEL_VALUE) {
        noinit_state.sentinel = NOINIT_SENTINEL_VALUE;
        noinit_state.total_uptime = 0;
        noinit_state.cumulative_hashes_high = 0;
        noinit_state.cumulative_hashes_low = 0;
    }

    // Load values from NVS (persist across power cycle)
    uint64_t nvs_total_uptime = nvs_config_get_u64(NVS_CONFIG_TOTAL_UPTIME);
    if (nvs_total_uptime > noinit_state.total_uptime) {
        noinit_state.total_uptime = nvs_total_uptime;
    }
    total_uptime_at_system_start = noinit_state.total_uptime;

    uint64_t nvs_hashes_high = nvs_config_get_u64(NVS_CONFIG_CUMULATIVE_HASHES_HIGH);
    uint64_t nvs_hashes_low = nvs_config_get_u64(NVS_CONFIG_CUMULATIVE_HASHES_LOW);
    if (nvs_hashes_high > noinit_state.cumulative_hashes_high) {
        noinit_state.cumulative_hashes_high = nvs_hashes_high;
        noinit_state.cumulative_hashes_low = nvs_hashes_low;
    } else if (nvs_hashes_high == noinit_state.cumulative_hashes_high &&
               nvs_hashes_low > noinit_state.cumulative_hashes_low) {
        noinit_state.cumulative_hashes_low = nvs_hashes_low;
    }

    // Initialize network address strings
    strcpy(module->ip_addr_str, "");
    strcpy(module->ipv6_addr_str, "");
    strcpy(module->wifi_status, "Initializing...");
    
    // set the pool configurations
    for (int i = 0; i < MAX_POOLS; i++) {
        module->pools[i].url = NULL;
        module->pools[i].user = NULL;
        module->pools[i].pass = NULL;
        module->pools[i].cert = NULL;
        module->pools[i].sv2_authority_pubkey = NULL;
        SYSTEM_load_pool_from_nvs(GLOBAL_STATE, i);
    }

    // load primary and secondary pool index selectors
    module->primary_pool_index = nvs_config_get_u16(NVS_CONFIG_PRIMARY_POOL_INDEX);
    module->secondary_pool_index = nvs_config_get_u16(NVS_CONFIG_SECONDARY_POOL_INDEX);

    if (module->primary_pool_index >= MAX_POOLS) {
        module->primary_pool_index = 0;
    }
    if (module->secondary_pool_index >= MAX_POOLS) {
        module->secondary_pool_index = 1;
    }

    // use fallback stratum
    module->use_fallback_stratum = nvs_config_get_bool(NVS_CONFIG_USE_FALLBACK_STRATUM);

    // set based on config
    module->is_using_fallback = module->use_fallback_stratum;

    // Initialize pool connection info
    strcpy(module->pool_connection_info, "Not Connected");

    // Initialize overheat_mode
    module->overheat_mode = nvs_config_get_bool(NVS_CONFIG_OVERHEAT_MODE);
    ESP_LOGI(TAG, "Initial overheat_mode value: %d", module->overheat_mode);

    module->mining_paused = false;
    module->pools_unavailable = false;

    //Initialize power_fault fault mode
    module->power_fault = 0;

    // set the best diff string
    suffixString(module->best_nonce_diff, module->best_diff_string, DIFF_STRING_SIZE, 0);
    suffixString(module->best_session_nonce_diff, module->best_session_diff_string, DIFF_STRING_SIZE, 0);

    // Load stratum protocol selection from the active pool configuration
    uint16_t active_pool_idx = module->is_using_fallback ? module->secondary_pool_index : module->primary_pool_index;
    GLOBAL_STATE->stratum_protocol = module->pools[active_pool_idx].protocol;
    GLOBAL_STATE->sv2_conn = NULL;

    // Initialize mutexes
    pthread_mutex_init(&GLOBAL_STATE->valid_jobs_lock, NULL);
    GLOBAL_STATE->stratum_mux = (portMUX_TYPE)portMUX_INITIALIZER_UNLOCKED;

    // Allocate the job tracking tables here rather than in create_jobs_task().
    // The stratum tasks touch valid_jobs (SYSTEM_clean_jobs_queue) as soon as they
    // connect, so tying the allocation to create_jobs_task actually starting is a
    // NULL dereference waiting to happen if that task ever fails to spawn.
    GLOBAL_STATE->ASIC_TASK_MODULE.active_jobs = heap_caps_calloc(MAX_ASIC_JOBS, sizeof(bm_job *), MALLOC_CAP_SPIRAM);
    GLOBAL_STATE->valid_jobs = heap_caps_calloc(MAX_ASIC_JOBS, sizeof(uint8_t), MALLOC_CAP_SPIRAM);
    if (GLOBAL_STATE->ASIC_TASK_MODULE.active_jobs == NULL || GLOBAL_STATE->valid_jobs == NULL) {
        ESP_LOGE(TAG, "Failed to allocate job tracking tables");
        abort();
    }
}

void SYSTEM_init_versions(GlobalState * GLOBAL_STATE)
{
    const esp_app_desc_t *app_desc = esp_app_get_description();
    
    // Store the firmware version
    GLOBAL_STATE->SYSTEM_MODULE.version = strdup(app_desc->version);
    if (GLOBAL_STATE->SYSTEM_MODULE.version == NULL) {
        ESP_LOGE(TAG, "Failed to allocate memory for version");
        GLOBAL_STATE->SYSTEM_MODULE.version = strdup("Unknown");
    }
    
    bool use_custom = nvs_config_get_bool(NVS_CONFIG_USE_CUSTOM_WWW) && GLOBAL_STATE->filesystem_is_available;
    char version[64] = "Unified";

    if (use_custom) {
        // Read AxeOS version from SPIFFS
        FILE *f = fopen("/version.txt", "r");
        if (f != NULL) {
            if (fgets(version, sizeof(version), f) != NULL) {
                // Remove trailing newline if present
                size_t len = strlen(version);
                if (len > 0 && version[len - 1] == '\n') {
                    version[len - 1] = '\0';
                }
            }
            fclose(f);
        } else {
            strlcpy(version, "Unknown", sizeof(version));
            ESP_LOGW(TAG, "Failed to open /version.txt from SPIFFS");
        }
    }

    GLOBAL_STATE->SYSTEM_MODULE.axeOSVersion = strdup(version);
    if (GLOBAL_STATE->SYSTEM_MODULE.axeOSVersion == NULL) {
        GLOBAL_STATE->SYSTEM_MODULE.axeOSVersion = strdup("Unknown");
    }
    
    ESP_LOGI(TAG, "Firmware Version: %s", GLOBAL_STATE->SYSTEM_MODULE.version);
    ESP_LOGI(TAG, "AxeOS Version: %s", GLOBAL_STATE->SYSTEM_MODULE.axeOSVersion);
}

esp_err_t SYSTEM_init_peripherals(GlobalState * GLOBAL_STATE) {
    esp_err_t ret = gpio_install_isr_service(0);
    if (ret != ESP_OK) {
        self_test_show_message(GLOBAL_STATE, "ISR:FAIL");
        ESP_LOGE(TAG, "Error installing ISR service");
        return ret;
    }

    ret = display_init(GLOBAL_STATE);
    if (ret != ESP_OK) {
        self_test_show_message(GLOBAL_STATE, "DISPLAY:FAIL");
        ESP_LOGE(TAG, "Display init failed");
        return ret;
    }

    if (!GLOBAL_STATE->SELF_TEST_MODULE.is_active) {
        ret = input_init(screen_button_press, toggle_wifi_softap);
    } else {
        ret = input_init(NULL, self_test_reset);
    }
    if (ret != ESP_OK) {
        self_test_show_message(GLOBAL_STATE, "INPUT:FAIL");
        ESP_LOGE(TAG, "Input init failed");
        return ret;
    }

    ret = screen_start(GLOBAL_STATE);
    if (ret != ESP_OK) {
        self_test_show_message(GLOBAL_STATE, "SCREEN:FAIL");
        ESP_LOGE(TAG, "Screen start failed");
        return ret;
    }

    ret = ensure_overheat_mode_config();
    if (ret != ESP_OK) {
        self_test_show_message(GLOBAL_STATE, "CONFIG:FAIL");
        ESP_LOGE(TAG, "Failed to ensure overheat_mode config");
        return ret;
    }

    if (nvs_config_get_bool(NVS_CONFIG_USE_CUSTOM_WWW)) {
        ret = filesystem_init(GLOBAL_STATE);
        if (ret != ESP_OK) {
            self_test_show_message(GLOBAL_STATE, "FILESYS:FAIL");
            ESP_LOGE(TAG, "Filesystem init failed");
            if (GLOBAL_STATE->SELF_TEST_MODULE.is_active) {
                return ret;
            }
        }
    } else {
        GLOBAL_STATE->filesystem_is_available = false;
        ESP_LOGI(TAG, "Custom WWW disabled; skipping SPIFFS filesystem initialization");
    }

    // Initialize the core voltage regulator
    ret = VCORE_init(GLOBAL_STATE);
    if (ret != ESP_OK) {
        self_test_show_message(GLOBAL_STATE, "VCORE:FAIL");
        ESP_LOGE(TAG, "VCORE init failed");
        return ret;
    }

    // For self-test, we set a stable known voltage before ASIC initialization
    if (GLOBAL_STATE->SELF_TEST_MODULE.is_active) {
        vTaskDelay(500 / portTICK_PERIOD_MS);

        ret = VCORE_set_voltage(GLOBAL_STATE, (float)GLOBAL_STATE->DEVICE_CONFIG.family.asic.default_voltage_mv / 1000.0f);
        if (ret != ESP_OK) {
            self_test_show_message(GLOBAL_STATE, "VCORE:FAIL");
            ESP_LOGE(TAG, "VCORE set failed");
            return ret;
        }
    }

    ret = Thermal_init(&GLOBAL_STATE->DEVICE_CONFIG);
    if (ret != ESP_OK) {
        self_test_show_message(GLOBAL_STATE, "THERMAL:FAIL");
        ESP_LOGE(TAG, "Thermal init failed");
        return ret;
    }

    return ESP_OK;
}

void SYSTEM_clean_jobs_queue(GlobalState * GLOBAL_STATE)
{
    ESP_LOGI(TAG, "Clean Jobs: clearing queue");
    queue_clear(&GLOBAL_STATE->stratum_queue);

    pthread_mutex_lock(&GLOBAL_STATE->valid_jobs_lock);
    for (int i = 0; i < MAX_ASIC_JOBS; i = i + 4) {
        GLOBAL_STATE->valid_jobs[i] = 0;
    }
    pthread_mutex_unlock(&GLOBAL_STATE->valid_jobs_lock);

    // Reset hashrate measurements to prevent a spike on reconnection
    hashrate_monitor_reset_measurements(GLOBAL_STATE);
}

void SYSTEM_notify_accepted_share(GlobalState * GLOBAL_STATE)
{
    SystemModule * module = &GLOBAL_STATE->SYSTEM_MODULE;

    module->shares_accepted++;
}

static int compare_rejected_reason_stats(const void *a, const void *b) {
    const RejectedReasonStat *ea = a;
    const RejectedReasonStat *eb = b;
    return (eb->count > ea->count) - (ea->count > eb->count);
}

void SYSTEM_notify_rejected_share(GlobalState * GLOBAL_STATE, char * error_msg)
{
    SystemModule * module = &GLOBAL_STATE->SYSTEM_MODULE;

    module->shares_rejected++;

    for (int i = 0; i < module->rejected_reason_stats_count; i++) {
        if (strncmp(module->rejected_reason_stats[i].message, error_msg, sizeof(module->rejected_reason_stats[i].message) - 1) == 0) {
            module->rejected_reason_stats[i].count++;
            return;
        }
    }

    if (module->rejected_reason_stats_count < (int)(sizeof(module->rejected_reason_stats) / sizeof(module->rejected_reason_stats[0]))) {
        strncpy(module->rejected_reason_stats[module->rejected_reason_stats_count].message, 
                error_msg, 
                sizeof(module->rejected_reason_stats[module->rejected_reason_stats_count].message) - 1);
        module->rejected_reason_stats[module->rejected_reason_stats_count].message[sizeof(module->rejected_reason_stats[module->rejected_reason_stats_count].message) - 1] = '\0'; // Ensure null termination
        module->rejected_reason_stats[module->rejected_reason_stats_count].count = 1;
        module->rejected_reason_stats_count++;
    }

    if (module->rejected_reason_stats_count > 1) {
        qsort(module->rejected_reason_stats, module->rejected_reason_stats_count, 
            sizeof(module->rejected_reason_stats[0]), compare_rejected_reason_stats);
    }    
}

void SYSTEM_notify_new_ntime(GlobalState * GLOBAL_STATE, uint32_t ntime)
{
    SystemModule * module = &GLOBAL_STATE->SYSTEM_MODULE;

    // Hourly clock sync
    if (module->lastClockSync + (60 * 60) > ntime) {
        return;
    }
    ESP_LOGI(TAG, "Syncing clock");
    module->lastClockSync = ntime;
    struct timeval tv;
    tv.tv_sec = ntime;
    tv.tv_usec = 0;
    settimeofday(&tv, NULL);
}

void SYSTEM_notify_found_nonce(GlobalState * GLOBAL_STATE, double diff, uint32_t target)
{
    SystemModule * module = &GLOBAL_STATE->SYSTEM_MODULE;

    if ((uint64_t) diff > module->best_session_nonce_diff) {
        module->best_session_nonce_diff = (uint64_t) diff;
        suffixString((uint64_t) diff, module->best_session_diff_string, DIFF_STRING_SIZE, 0);
    }

    double network_diff = networkDifficulty(target);
    if (diff >= network_diff) {
        module->block_found++;
        module->show_new_block = true;
        ESP_LOGI(TAG, "FOUND BLOCK!!!!!!!!!!!!!!!!!!!!!! %f >= %f (count: %d)", diff, network_diff, module->block_found);
    }

    if ((uint64_t) diff <= module->best_nonce_diff) {
        return;
    }
    module->best_nonce_diff = (uint64_t) diff;

    nvs_config_set_u64(NVS_CONFIG_BEST_DIFF, module->best_nonce_diff);

    // make the best_nonce_diff into a string
    suffixString((uint64_t) diff, module->best_diff_string, DIFF_STRING_SIZE, 0);

    ESP_LOGI(TAG, "New best difficulty: %s", module->best_diff_string);
}

static esp_err_t ensure_overheat_mode_config() {
    bool overheat_mode = nvs_config_get_bool(NVS_CONFIG_OVERHEAT_MODE);

    ESP_LOGI(TAG, "Existing overheat_mode value: %d", overheat_mode);

    return ESP_OK;
}

void SYSTEM_noinit_update(SystemModule * SYSTEM_MODULE)
{
    uint64_t current_time_ms = esp_timer_get_time() / 1000;
    
    // Initialize last_update_time on first call
    if (last_update_time_ms == 0) {
        last_update_time_ms = current_time_ms;
        last_nvs_write_time_ms = current_time_ms;
        return;
    }

    uint64_t elapsed_ms = current_time_ms - last_update_time_ms;
    last_update_time_ms = current_time_ms;
    
    // Only update if at least 1 second has passed
    if (elapsed_ms < 1000) {
        return;
    }
    
    SYSTEM_MODULE->uptime_seconds = (esp_timer_get_time() - SYSTEM_MODULE->start_time_us) / 1000000;
    noinit_state.total_uptime = total_uptime_at_system_start + SYSTEM_MODULE->uptime_seconds;
    
    // Update cumulative hashes: hashrate (GH/s) × milliseconds × 1e6 = raw hashes
    uint64_t hashes_done = elapsed_ms * 1e6 * SYSTEM_MODULE->current_hashrate;
    uint64_t new_low = noinit_state.cumulative_hashes_low + hashes_done;
    if (new_low < noinit_state.cumulative_hashes_low) {
        noinit_state.cumulative_hashes_high++;
    }
    noinit_state.cumulative_hashes_low = new_low;

    // Persist to NVS once per hour to reduce wear
    if (current_time_ms - last_nvs_write_time_ms >= NVS_COUNTER_UPDATE_INTERVAL_MS) {
        nvs_config_set_u64(NVS_CONFIG_TOTAL_UPTIME, noinit_state.total_uptime);
        nvs_config_set_u64(NVS_CONFIG_CUMULATIVE_HASHES_HIGH, noinit_state.cumulative_hashes_high);
        nvs_config_set_u64(NVS_CONFIG_CUMULATIVE_HASHES_LOW, noinit_state.cumulative_hashes_low);
        last_nvs_write_time_ms = current_time_ms;
    }
}

uint64_t SYSTEM_noinit_get_total_uptime_seconds()
{
    return noinit_state.total_uptime;
}

// Convert 128-bit to double: high * 2^64 + low. Loses precision for very large values, but sufficient for display
double SYSTEM_noinit_get_total_hashes()
{
    return (double)noinit_state.cumulative_hashes_high * 18446744073709551616.0 + (double)noinit_state.cumulative_hashes_low;
}

double SYSTEM_noinit_get_total_log2_work()
{
    // If high part is 0, just compute log2 of low part
    if (noinit_state.cumulative_hashes_high == 0) {
        if (noinit_state.cumulative_hashes_low == 0) {
            return 0.0;
        }
        return log2((double)noinit_state.cumulative_hashes_low);
    }
    
    // For 128-bit value: log2(high * 2^64 + low) = 64 + log2(high + low/2^64)
    // Since low/2^64 is very small compared to high, we approximate:
    // log2(high * 2^64 + low) ≈ 64 + log2(high) for large values
    // More precise: 64 + log2(high + low/2^64)
    double high_plus_fraction = (double)noinit_state.cumulative_hashes_high + 
                                (double)noinit_state.cumulative_hashes_low / 18446744073709551616.0;
    return 64.0 + log2(high_plus_fraction);
}

stratum_protocol_t stratum_protocol_from_string(const char *s)
{
    if (!s) return STRATUM_PROTOCOL_UNKNOWN;
    if (strcmp(s, STRATUM_V1) == 0) return STRATUM_PROTOCOL_V1;
    if (strcmp(s, STRATUM_V2) == 0) return STRATUM_PROTOCOL_V2;
    return STRATUM_PROTOCOL_UNKNOWN;
}

sv2_channel_type_t sv2_channel_type_from_string(const char *s)
{
    if (!s) return SV2_CHANNEL_UNKNOWN;
    if (strcmp(s, SV2_CHANNEL_TYPE_EXTENDED) == 0) return SV2_CHANNEL_EXTENDED;
    if (strcmp(s, SV2_CHANNEL_TYPE_STANDARD) == 0) return SV2_CHANNEL_STANDARD;
    return SV2_CHANNEL_UNKNOWN;
}

void SYSTEM_init_partitions(GlobalState * GLOBAL_STATE) {
    if (!GLOBAL_STATE) return;
    SystemModule *module = &GLOBAL_STATE->SYSTEM_MODULE;
    module->cached_partitions_count = 0;
    const esp_partition_t *running = esp_ota_get_running_partition();
    esp_partition_iterator_t it = esp_partition_find(ESP_PARTITION_TYPE_APP, ESP_PARTITION_SUBTYPE_ANY, NULL);
    while (it != NULL && module->cached_partitions_count < 3) {
        const esp_partition_t *p = esp_partition_get(it);

        // We only care about factory, ota_0, ota_1
        if (strcmp(p->label, "factory") == 0 || strcmp(p->label, "ota_0") == 0 || strcmp(p->label, "ota_1") == 0) {
            cached_partition_t *cp = &module->cached_partitions[module->cached_partitions_count];
            cp->part = p;
            cp->isCurrent = (p == running);
            cp->version[0] = '\0';
            cp->compileDate[0] = '\0';
            cp->compileTime[0] = '\0';
            cp->usagePercent = -1;

            esp_app_desc_t app_desc;
            if (esp_ota_get_partition_description(p, &app_desc) == ESP_OK) {
                snprintf(cp->version, sizeof(cp->version), "%s", app_desc.version);
                snprintf(cp->compileDate, sizeof(cp->compileDate), "%s", app_desc.date);
                snprintf(cp->compileTime, sizeof(cp->compileTime), "%s", app_desc.time);
                
                esp_partition_pos_t part_pos = {
                    .offset = p->address,
                    .size = p->size,
                };
                esp_image_metadata_t metadata;
                if (esp_image_get_metadata(&part_pos, &metadata) == ESP_OK) {
                    cp->usagePercent = (metadata.image_len * 100) / p->size;
                }
            }
            module->cached_partitions_count++;
        }
        it = esp_partition_next(it);
    }
    if (it != NULL) {
        esp_partition_iterator_release(it);
    }
}

void SYSTEM_load_pool_from_nvs(GlobalState * GLOBAL_STATE, int i) {
    if (i < 0 || i >= MAX_POOLS) return;
    
    PoolConfig *cfg = &GLOBAL_STATE->SYSTEM_MODULE.pools[i];
    free(cfg->url);
    free(cfg->user);
    free(cfg->pass);
    free(cfg->cert);
    free(cfg->sv2_authority_pubkey);
    
    cfg->url = NULL;
    cfg->user = NULL;
    cfg->pass = NULL;
    cfg->cert = NULL;
    cfg->sv2_authority_pubkey = NULL;

    char *json_str = nvs_config_get_string_indexed(NVS_CONFIG_POOL, i);
    parse_pool_config_json(json_str, cfg, i);
    free(json_str);
}
