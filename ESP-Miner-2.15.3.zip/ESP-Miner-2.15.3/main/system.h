#ifndef SYSTEM_H_
#define SYSTEM_H_

#include "esp_err.h"

#include "sv2_protocol.h"

typedef struct GlobalState GlobalState;
typedef struct SystemModule SystemModule;

typedef enum {
    STRATUM_PROTOCOL_UNKNOWN = 0,
    STRATUM_PROTOCOL_V1 = 1,
    STRATUM_PROTOCOL_V2 = 2,
} stratum_protocol_t;

#define STRATUM_V1 "SV1"
#define STRATUM_V2 "SV2"

void SYSTEM_check_firmware_migration(void);
void SYSTEM_reset_custom_www(void);
void SYSTEM_init_system(GlobalState * GLOBAL_STATE);
void SYSTEM_init_versions(GlobalState * GLOBAL_STATE);
void SYSTEM_init_partitions(GlobalState * GLOBAL_STATE);
esp_err_t SYSTEM_init_peripherals(GlobalState * GLOBAL_STATE);

// Clear the stratum job queue and valid-job tracking on a clean-jobs event,
// and reset hashrate measurements so reconnects don't spike the average.
// Shared by the SV1 and SV2 tasks.
void SYSTEM_clean_jobs_queue(GlobalState * GLOBAL_STATE);

void SYSTEM_notify_accepted_share(GlobalState * GLOBAL_STATE);
void SYSTEM_notify_rejected_share(GlobalState * GLOBAL_STATE, char * error_msg);
void SYSTEM_notify_found_nonce(GlobalState * GLOBAL_STATE, double diff, uint32_t target);
void SYSTEM_notify_new_ntime(GlobalState * GLOBAL_STATE, uint32_t ntime);

void SYSTEM_noinit_update(SystemModule * SYSTEM_MODULE);
uint64_t SYSTEM_noinit_get_total_uptime_seconds();
double SYSTEM_noinit_get_total_hashes();
double SYSTEM_noinit_get_total_log2_work();
stratum_protocol_t stratum_protocol_from_string(const char *s);
sv2_channel_type_t sv2_channel_type_from_string(const char *s);
void SYSTEM_load_pool_from_nvs(GlobalState * GLOBAL_STATE, int i);

#endif /* SYSTEM_H_ */
